package com.sepgroup.sep;

/**
 * Created by jeremybrown on 2016-05-18.
 */
public interface Observer {
    void update();
}
