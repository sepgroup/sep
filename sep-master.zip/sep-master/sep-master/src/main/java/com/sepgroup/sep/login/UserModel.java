package com.sepgroup.sep.login;

/**
 * Created by jeremybrown on 2016-05-17.
 */
public class UserModel {
    int userId;

    /**
     *
     * @return
     */
    public int getUserId() {
        return userId;
    }

    /**
     *
     * @param userId
     */
    private void setUserId(int userId) {
        this.userId = userId;
    }
}
